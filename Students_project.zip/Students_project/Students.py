# -*- coding: utf-8 -*-
"""
Created on Sat Jul 14 11:51:31 2018

@author: Krishnamoorthy KBhat
"""

import numpy as np
from numpy.random import randn
import pandas as pd
#import dataset & assign to a variable
data1=pd.read_csv('student/student-mat.csv',sep=';')
#display top 5 rows of data
data1.shape
data1.head()#gives 1st 5 values of all the columns
data1.info()
a=data1.columns#gives all column names
print(a)
#df=pd.DataFrame(randn(5,4),index=['A','B','C','D','E'],columns=['W','X','Y','Z'])
data1.iloc[:11]#from school to guardian columns
f=lambda data1:data1.upper()#upper or capitalize
#capitalize mjob & fjob
c=lambda data1:data1.capitalize()
data1['Mjob'].apply(c)
data1['Fjob'].apply(c)
#data1[['Mjob','Fjob']].apply(c)
def majority(x):
    if x>17:
        return True
    else:
        return False
    
data1['legal_drinker']=data1['age'].apply(majority)

def times10(x):
    if type(x) is int:
        return 10*x
    return x

data1.applymap(times10).head(10)


d1="10/24/2017"
d2="11/24/2016"
max(d1,d2)
d1-d2#ERROR




import datetime
d1=datetime.date(2016,11,24)
d2=datetime.date(2017,10,24)
max(d1,d2)
print(d1-d2)


import datetime
century_start=datetime.date(2000,1,1)
today=datetime.date.today()
print(century_start,today)
print("We are",today-century_start,"days into this century")



